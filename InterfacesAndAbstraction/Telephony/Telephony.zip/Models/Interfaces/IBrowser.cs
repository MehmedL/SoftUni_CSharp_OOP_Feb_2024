﻿namespace Telephony.Models.Interfaces
{
    public interface IBrowser
    {
        void Browse(string url);
    }
}
