﻿namespace Border_Control.Models
{
    public abstract class BaseEntity
    {
        public string Id { get; set; }
    }
}
