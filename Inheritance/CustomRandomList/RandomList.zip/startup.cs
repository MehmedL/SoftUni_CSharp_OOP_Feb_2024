﻿using System;

namespace CustomRandomList
{
    public class startup
    {
        static void Main(string[] args)
        {
            
        }
    }
}
