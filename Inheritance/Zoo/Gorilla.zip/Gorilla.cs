﻿
namespace Zoo
{
    public class Gorilla : Mammal
    {
        public string Name { get; set; }
        public Gorilla(string name) : base(name)
        {
        }
    }
}
